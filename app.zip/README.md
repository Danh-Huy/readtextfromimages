Web App: https://image-to-text-computer-vision.herokuapp.com/

Description of the Project: https://medium.com/@shoaib6174/build-a-web-app-to-extract-text-from-image-using-flask-and-azures-computer-vision-api-1ee470b66050
